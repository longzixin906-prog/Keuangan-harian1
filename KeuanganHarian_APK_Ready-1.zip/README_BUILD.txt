KEUANGAN HARIAN — APK READY

Cara compile:
1. Buka folder ini di Android Studio.
2. Tunggu Gradle selesai sync.
3. Pilih Build > Build APK(s).
4. APK debug akan berada di:
   app/build/outputs/apk/debug/app-debug.apk

Aplikasi berjalan offline dan menyimpan transaksi secara lokal di HP.
Fitur:
- Pemasukan
- Pengeluaran harian
- Kategori
- Saldo
- Batas pengeluaran harian
- Status "BAIK — Tidak Boros" / "BOROS"
- Riwayat dan catatan
- Edit/hapus transaksi dapat ditambahkan pada versi berikutnya

Tidak ada internet permission sehingga aplikasi tidak membutuhkan koneksi internet.
